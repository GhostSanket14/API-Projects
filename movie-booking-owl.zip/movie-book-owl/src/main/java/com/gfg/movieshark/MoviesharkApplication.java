package com.gfg.movieshark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviesharkApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviesharkApplication.class, args);
	}

}
