package com.gfg.movieshark.enums;


public enum Genre {

    ACTION,
    COMEDY,
    THRILLER,
    ROMANCE,
    SCI_FI,
    DRAMA,
}
