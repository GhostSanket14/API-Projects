
package com.gfg.movieshark.enums;

public enum SeatType {

	REGULAR,
	RECLINER
}