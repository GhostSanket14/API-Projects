package com.gfg.movieshark.enums;

public enum Role {
    USER,
    ADMIN
}
